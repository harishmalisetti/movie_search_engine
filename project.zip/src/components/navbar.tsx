
"use client";

import Link from 'next/link';
import { ShoppingBag, Heart, Search, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStore } from '@/components/store-provider';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';
import { SearchOverlay } from '@/components/search-overlay';

export function Navbar() {
  const { cart, wishlist, setCartOpen } = useStore();
  const [isSearchOpen, setSearchOpen] = useState(false);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-5 w-5" />
          </Button>
          <Link href="/" className="text-2xl font-headline font-bold text-primary tracking-tight">
            Aura
          </Link>
        </div>

        <div className="hidden lg:flex items-center space-x-8 text-sm font-medium uppercase tracking-widest">
          <Link href="/" className="hover:text-primary transition-colors">Shop All</Link>
          <Link href="/category/apparel" className="hover:text-primary transition-colors">Apparel</Link>
          <Link href="/category/accessories" className="hover:text-primary transition-colors">Accessories</Link>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)}>
            <Search className="h-5 w-5" />
          </Button>
          <Link href="/wishlist">
            <Button variant="ghost" size="icon" className="relative">
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && (
                <Badge className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-[10px]">
                  {wishlist.length}
                </Badge>
              )}
            </Button>
          </Link>
          <Button variant="ghost" size="icon" className="relative" onClick={() => setCartOpen(true)}>
            <ShoppingBag className="h-5 w-5" />
            {cartCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-[10px]">
                {cartCount}
              </Badge>
            )}
          </Button>
        </div>
      </div>
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setSearchOpen(false)} />
    </nav>
  );
}
