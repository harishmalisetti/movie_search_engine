
"use client";

import Image from 'next/image';
import Link from 'next/link';
import { Heart, Plus } from 'lucide-react';
import { Product } from '@/app/lib/products';
import { Button } from '@/components/ui/button';
import { useStore } from '@/components/store-provider';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export function ProductCard({ product }: { product: Product }) {
  const { toggleWishlist, wishlist, addToCart } = useStore();
  const isWishlisted = wishlist.some(item => item.id === product.id);

  return (
    <div className="group relative flex flex-col space-y-4">
      <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-muted">
        <Link href={`/products/${product.id}`}>
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
        </Link>
        <div className="absolute top-4 right-4 z-10">
          <Button
            variant="secondary"
            size="icon"
            className="rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            onClick={(e) => {
              e.preventDefault();
              toggleWishlist(product);
            }}
          >
            <Heart className={cn("h-5 w-5", isWishlisted && "fill-current text-primary")} />
          </Button>
        </div>
        
        {product.stock < 5 && (
          <div className="absolute bottom-4 left-4">
            <Badge variant="secondary" className="bg-white/90 backdrop-blur text-primary border-none">
              Only {product.stock} left
            </Badge>
          </div>
        )}

        <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/50 to-transparent">
          <Button 
            className="w-full bg-white text-black hover:bg-white/90 border-none"
            onClick={() => addToCart(product)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Quick Add
          </Button>
        </div>
      </div>

      <div className="flex flex-col space-y-1">
        <div className="flex items-center justify-between">
          <Link href={`/products/${product.id}`} className="hover:underline underline-offset-4">
            <h3 className="font-medium text-base">{product.name}</h3>
          </Link>
          <span className="text-sm font-semibold">${product.price}</span>
        </div>
        <p className="text-sm text-muted-foreground">{product.category}</p>
      </div>
    </div>
  );
}
