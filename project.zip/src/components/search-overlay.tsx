
"use client";

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2, Sparkles } from 'lucide-react';
import { intelligentProductSearch } from '@/ai/flows/intelligent-product-search';
import Link from 'next/link';

export function SearchOverlay({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    try {
      const response = await intelligentProductSearch({ query });
      setResults(response.suggestions);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] top-[20%] translate-y-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-secondary" />
            Intelligent Search
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSearch} className="relative mt-4">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by style, occasion, or intent (e.g. 'something elegant for a winter gala')..."
            className="pr-12 h-12"
          />
          <Button 
            type="submit" 
            size="icon" 
            variant="ghost" 
            className="absolute right-1 top-1 h-10 w-10"
            disabled={isLoading}
          >
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-5 w-5" />}
          </Button>
        </form>

        <div className="mt-6 space-y-4">
          {isLoading && (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground animate-pulse">
              <Sparkles className="h-8 w-8 mb-2" />
              <p>Aura AI is curating suggestions...</p>
            </div>
          )}

          {!isLoading && results.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">AI Recommendations</h4>
              <div className="grid gap-2">
                {results.map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setQuery(suggestion);
                      onClose();
                    }}
                    className="text-left p-3 rounded-lg hover:bg-accent transition-colors text-sm border border-transparent hover:border-border"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!isLoading && results.length === 0 && query && (
            <p className="text-center py-8 text-sm text-muted-foreground">
              Try searching for "summer vacation outfits" or "formal evening wear"
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
