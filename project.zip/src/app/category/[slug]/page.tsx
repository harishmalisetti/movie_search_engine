
"use client";

import { useParams } from 'next/navigation';
import { PRODUCTS } from '@/app/lib/products';
import { Navbar } from '@/components/navbar';
import { ProductCard } from '@/components/product-card';
import { CartDrawer } from '@/components/cart-drawer';

export default function CategoryPage() {
  const { slug } = useParams();
  
  const categoryName = typeof slug === 'string' ? slug.charAt(0).toUpperCase() + slug.slice(1) : '';
  const filteredProducts = PRODUCTS.filter(p => p.category.toLowerCase() === (slug as string).toLowerCase());

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <div className="mb-12">
          <h1 className="text-5xl font-headline font-bold mb-4">{categoryName}</h1>
          <p className="text-muted-foreground max-w-2xl text-lg">
            Curated selection of premium {categoryName.toLowerCase()} designed for modern elegance and timeless appeal.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      <CartDrawer />
    </div>
  );
}
