
"use client";

import { useParams } from 'next/navigation';
import { PRODUCTS, Product } from '@/app/lib/products';
import { Navbar } from '@/components/navbar';
import { useStore } from '@/components/store-provider';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingBag, ArrowLeft, Truck, ShieldCheck, RefreshCcw, Sparkles } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { aiProductRecommendations } from '@/ai/flows/ai-product-recommendations';
import { ProductCard } from '@/components/product-card';
import { CartDrawer } from '@/components/cart-drawer';

export default function ProductDetailsPage() {
  const { id } = useParams();
  const { addToCart, toggleWishlist, wishlist } = useStore();
  const [recommendations, setRecommendations] = useState<Product[]>([]);
  const [reason, setReason] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(true);

  const product = PRODUCTS.find(p => p.id === id);
  if (!product) return <div>Product not found</div>;

  const isWishlisted = wishlist.some(item => item.id === product.id);

  useEffect(() => {
    async function getRecommendations() {
      try {
        const response = await aiProductRecommendations({
          currentProductId: product.id,
          currentProductDescription: product.description,
          browsingHistoryProductIds: [],
          browsingHistoryDescriptions: [],
          currentCategory: product.category
        });
        
        const recommendedProducts = PRODUCTS.filter(p => response.recommendedProductIds.includes(p.id));
        setRecommendations(recommendedProducts);
        setReason(response.recommendationReason);
      } catch (error) {
        console.error(error);
      } finally {
        setIsAiLoading(false);
      }
    }
    getRecommendations();
  }, [product]);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Collections
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Gallery */}
          <div className="space-y-4">
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-muted group">
              <Image
                src={product.imageUrl}
                alt={product.name}
                fill
                className="object-cover"
                priority
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-muted cursor-pointer hover:opacity-80 transition-opacity">
                  <Image
                    src={`https://picsum.photos/seed/${product.id}-${i}/400/400`}
                    alt={`${product.name} view ${i}`}
                    fill
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div className="flex flex-col space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-primary/5 text-primary border-none">
                  {product.category}
                </Badge>
                {product.stock < 5 && (
                  <Badge variant="destructive" className="animate-pulse">
                    Low Stock
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl md:text-5xl font-headline font-bold">{product.name}</h1>
              <p className="text-2xl font-semibold">${product.price}</p>
            </div>

            <p className="text-lg text-muted-foreground leading-relaxed">
              {product.description}
            </p>

            <div className="space-y-4 pt-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="flex-1 h-14 text-sm font-bold uppercase tracking-widest"
                  onClick={() => addToCart(product)}
                >
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Add to Bag
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="h-14 aspect-square p-0"
                  onClick={() => toggleWishlist(product)}
                >
                  <Heart className={cn("h-6 w-6", isWishlisted && "fill-current text-primary")} />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t">
              <div className="flex items-center gap-3 text-sm">
                <div className="p-2 rounded-full bg-muted">
                  <Truck className="h-4 w-4" />
                </div>
                <div>
                  <p className="font-semibold">Complimentary Shipping</p>
                  <p className="text-muted-foreground text-xs">On all luxury orders</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="p-2 rounded-full bg-muted">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <div>
                  <p className="font-semibold">Authentic Guaranteed</p>
                  <p className="text-muted-foreground text-xs">Certified quality</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="p-2 rounded-full bg-muted">
                  <RefreshCcw className="h-4 w-4" />
                </div>
                <div>
                  <p className="font-semibold">Bespoke Exchanges</p>
                  <p className="text-muted-foreground text-xs">Within 30 days</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* AI Recommendations Section */}
        <section className="mt-24 pt-16 border-t">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-secondary font-semibold uppercase tracking-widest text-xs">
                <Sparkles className="h-4 w-4" />
                Curated for you
              </div>
              <h2 className="text-3xl font-headline">The Aura Edit</h2>
              {reason && (
                <p className="text-muted-foreground italic text-sm max-w-lg mt-2">
                  "{reason}"
                </p>
              )}
            </div>
          </div>

          {isAiLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="space-y-4 animate-pulse">
                  <div className="aspect-[3/4] bg-muted rounded-xl" />
                  <div className="h-4 bg-muted w-3/4 rounded" />
                  <div className="h-4 bg-muted w-1/4 rounded" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {recommendations.length > 0 ? (
                recommendations.map(p => <ProductCard key={p.id} product={p} />)
              ) : (
                PRODUCTS.slice(0, 4).filter(p => p.id !== product.id).map(p => <ProductCard key={p.id} product={p} />)
              )}
            </div>
          )}
        </section>
      </main>

      <CartDrawer />
    </div>
  );
}
