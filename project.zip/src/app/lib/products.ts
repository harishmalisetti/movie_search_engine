
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl: string;
  stock: number;
  tags: string[];
}

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Midnight Silk Blouse',
    description: 'A luxurious silk blouse crafted from premium mulberry silk. Features a relaxed fit and elegant pearl buttons.',
    price: 245,
    category: 'Apparel',
    imageUrl: 'https://picsum.photos/seed/12/600/800',
    stock: 12,
    tags: ['luxury', 'silk', 'formal']
  },
  {
    id: 'p2',
    name: 'Premium Cashmere Sweater',
    description: 'Soft, warm, and timeless. Our cashmere sweater is ethically sourced and knitted for long-lasting comfort.',
    price: 380,
    category: 'Apparel',
    imageUrl: 'https://picsum.photos/seed/23/600/800',
    stock: 5,
    tags: ['winter', 'cashmere', 'classic']
  },
  {
    id: 'p3',
    name: 'Handcrafted Leather Bag',
    description: 'Italian calfskin leather handbag with minimalist hardware. Perfectly sized for your daily essentials.',
    price: 520,
    category: 'Accessories',
    imageUrl: 'https://picsum.photos/seed/45/600/800',
    stock: 3,
    tags: ['leather', 'handbag', 'artisan']
  },
  {
    id: 'p4',
    name: 'Italian Velvet Blazer',
    description: 'Statement velvet blazer in deep plum. Tailored silhouette with silk lapels.',
    price: 450,
    category: 'Apparel',
    imageUrl: 'https://picsum.photos/seed/56/600/800',
    stock: 8,
    tags: ['evening', 'velvet', 'suit']
  },
  {
    id: 'p5',
    name: 'Tailored Wool Trousers',
    description: 'High-waisted wool trousers with a slight flare. Breathable and sophisticated.',
    price: 210,
    category: 'Apparel',
    imageUrl: 'https://picsum.photos/seed/78/600/800',
    stock: 15,
    tags: ['business', 'wool', 'essential']
  },
  {
    id: 'p6',
    name: 'Minimalist Gold Watch',
    description: '18k gold-plated timepiece with a clean white dial and black leather strap.',
    price: 890,
    category: 'Accessories',
    imageUrl: 'https://picsum.photos/seed/89/600/800',
    stock: 2,
    tags: ['watch', 'gold', 'jewelry']
  },
  {
    id: 'p7',
    name: 'Summer Linen Dress',
    description: 'Lightweight linen dress with an asymmetrical hem. Ideal for garden parties and coastal walks.',
    price: 185,
    category: 'Apparel',
    imageUrl: 'https://picsum.photos/seed/91/600/800',
    stock: 20,
    tags: ['summer', 'linen', 'dress']
  },
  {
    id: 'p8',
    name: 'Designer Sunglasses',
    description: 'Classic oversized frames with gradient lenses. Provides 100% UV protection.',
    price: 260,
    category: 'Accessories',
    imageUrl: 'https://picsum.photos/seed/102/600/800',
    stock: 10,
    tags: ['eyewear', 'summer', 'luxury']
  }
];
