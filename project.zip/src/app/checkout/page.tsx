
"use client";

import { useStore } from '@/components/store-provider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Navbar } from '@/components/navbar';
import { ArrowLeft, Lock, ShieldCheck, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import Image from 'next/image';

export default function CheckoutPage() {
  const { cart, clearCart } = useStore();
  const [isOrdered, setIsOrdered] = useState(false);
  const [step, setStep] = useState(1);

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = 0;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const handleOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      setIsOrdered(true);
      clearCart();
    }
  };

  if (isOrdered) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center space-y-6 animate-in fade-in zoom-in duration-500">
            <div className="mx-auto w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <CheckCircle2 className="h-10 w-10 text-primary" />
            </div>
            <h1 className="text-4xl font-headline font-bold">Thank You</h1>
            <p className="text-muted-foreground leading-relaxed">
              Your order has been received and is being prepared with care. 
              A confirmation email has been sent to your inbox.
            </p>
            <div className="pt-8">
              <Link href="/">
                <Button className="w-full">Continue Shopping</Button>
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex flex-col items-center justify-center space-y-4">
          <p className="text-xl text-muted-foreground">Your bag is empty.</p>
          <Link href="/">
            <Button>Back to Store</Button>
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <div className="sticky top-0 z-50 bg-background border-b py-4">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-headline font-bold text-primary">Aura</Link>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">
            <Lock className="h-3 w-3" />
            Secure Checkout
          </div>
        </div>
      </div>

      <main className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Checkout Steps */}
          <div className="lg:col-span-2 space-y-12">
            <div className="flex items-center gap-8 text-xs font-bold uppercase tracking-widest mb-12 border-b pb-4">
              <span className={step >= 1 ? "text-primary border-b-2 border-primary pb-4 -mb-[18px]" : "text-muted-foreground"}>01. Shipping</span>
              <span className={step >= 2 ? "text-primary border-b-2 border-primary pb-4 -mb-[18px]" : "text-muted-foreground"}>02. Delivery</span>
              <span className={step >= 3 ? "text-primary border-b-2 border-primary pb-4 -mb-[18px]" : "text-muted-foreground"}>03. Payment</span>
            </div>

            <form onSubmit={handleOrder} className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
              {step === 1 && (
                <div className="space-y-8">
                  <h2 className="text-2xl font-headline">Shipping Information</h2>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>First Name</Label>
                      <Input placeholder="Elias" required />
                    </div>
                    <div className="space-y-2">
                      <Label>Last Name</Label>
                      <Input placeholder="Vance" required />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Email Address</Label>
                    <Input type="email" placeholder="elias@aura.com" required />
                  </div>
                  <div className="space-y-2">
                    <Label>Street Address</Label>
                    <Input placeholder="123 Luxury Lane" required />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>City</Label>
                      <Input placeholder="New York" required />
                    </div>
                    <div className="space-y-2">
                      <Label>State</Label>
                      <Input placeholder="NY" required />
                    </div>
                    <div className="space-y-2">
                      <Label>Zip Code</Label>
                      <Input placeholder="10001" required />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-8">
                  <h2 className="text-2xl font-headline">Delivery Method</h2>
                  <div className="space-y-4">
                    <label className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:border-primary transition-colors bg-background">
                      <div className="flex items-center gap-4">
                        <input type="radio" name="shipping" defaultChecked className="h-4 w-4 accent-primary" />
                        <div>
                          <p className="font-semibold">Standard Shipping</p>
                          <p className="text-xs text-muted-foreground">3-5 business days</p>
                        </div>
                      </div>
                      <span className="font-medium">Free</span>
                    </label>
                    <label className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:border-primary transition-colors bg-background">
                      <div className="flex items-center gap-4">
                        <input type="radio" name="shipping" className="h-4 w-4 accent-primary" />
                        <div>
                          <p className="font-semibold">Express Delivery</p>
                          <p className="text-xs text-muted-foreground">Next day arrival</p>
                        </div>
                      </div>
                      <span className="font-medium">$25.00</span>
                    </label>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-8">
                  <h2 className="text-2xl font-headline">Payment Method</h2>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Cardholder Name</Label>
                      <Input placeholder="Elias Vance" required />
                    </div>
                    <div className="space-y-2">
                      <Label>Card Number</Label>
                      <Input placeholder="0000 0000 0000 0000" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Expiry Date</Label>
                        <Input placeholder="MM/YY" required />
                      </div>
                      <div className="space-y-2">
                        <Label>CVV</Label>
                        <Input placeholder="123" required />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-8 border-t flex flex-col sm:flex-row gap-4">
                {step > 1 && (
                  <Button type="button" variant="outline" className="flex-1 h-14" onClick={() => setStep(step - 1)}>
                    Back
                  </Button>
                )}
                <Button type="submit" className="flex-[2] h-14 font-bold uppercase tracking-widest">
                  {step === 3 ? "Complete Purchase" : "Next Step"}
                </Button>
              </div>
            </form>
          </div>

          {/* Order Summary */}
          <div className="space-y-8 lg:sticky lg:top-32 h-fit">
            <div className="bg-background rounded-2xl p-6 shadow-sm space-y-6">
              <h3 className="text-xl font-headline font-bold">Order Summary</h3>
              <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
                {cart.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="relative h-16 w-12 rounded bg-muted overflow-hidden flex-shrink-0">
                      <Image src={item.imageUrl} alt={item.name} fill className="object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-sm font-medium">${(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                ))}
              </div>
              
              <div className="space-y-2 pt-6 border-t text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-green-600">Complimentary</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${tax.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between pt-4 border-t text-lg font-bold">
                  <span>Total</span>
                  <span className="text-primary">${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 p-4 bg-muted/50 rounded-lg text-xs text-muted-foreground">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Your data is protected by industry-standard encryption.
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
