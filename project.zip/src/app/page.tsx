
import { Navbar } from '@/components/navbar';
import { ProductCard } from '@/components/product-card';
import { PRODUCTS } from '@/app/lib/products';
import { CartDrawer } from '@/components/cart-drawer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[80vh] w-full bg-primary flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="https://picsum.photos/seed/fashion/1920/1080"
              alt="Hero Fashion"
              fill
              className="object-cover opacity-60 mix-blend-overlay"
              priority
              data-ai-hint="fashion model"
            />
          </div>
          <div className="relative z-10 text-center text-white px-4 max-w-3xl space-y-6">
            <h1 className="text-5xl md:text-7xl font-headline font-bold leading-tight">
              Aesthetics for the <span className="italic font-normal">Discerning</span>
            </h1>
            <p className="text-lg md:text-xl font-light tracking-wide opacity-90 max-w-2xl mx-auto">
              Curating luxury essentials that define modern sophistication. 
              Explore our latest collection designed for the effortless elite.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-bold px-8 py-6 uppercase tracking-widest text-xs h-auto">
                Shop Collection
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10 font-bold px-8 py-6 uppercase tracking-widest text-xs h-auto">
                The Lookbook
              </Button>
            </div>
          </div>
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <div className="w-[1px] h-16 bg-white/50" />
          </div>
        </section>

        {/* Product Catalog */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 space-y-4 md:space-y-0">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-secondary font-semibold uppercase tracking-[0.2em] text-xs">
                <Sparkles className="h-3 w-3" />
                Featured Arrivals
              </div>
              <h2 className="text-4xl font-headline">The Season's Best</h2>
            </div>
            <div className="flex items-center gap-8 text-sm font-medium uppercase tracking-widest overflow-x-auto pb-2 scrollbar-hide">
              <button className="text-primary border-b border-primary whitespace-nowrap">All Items</button>
              <button className="text-muted-foreground hover:text-primary transition-colors whitespace-nowrap">New In</button>
              <button className="text-muted-foreground hover:text-primary transition-colors whitespace-nowrap">Exclusives</button>
              <button className="text-muted-foreground hover:text-primary transition-colors whitespace-nowrap">Bestsellers</button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
            {PRODUCTS.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="mt-20 text-center">
            <Button variant="outline" size="lg" className="rounded-full px-12 group">
              View Entire Collection
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
        </section>

        {/* Luxury CTA */}
        <section className="bg-muted py-24">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="relative aspect-square overflow-hidden rounded-2xl">
              <Image 
                src="https://picsum.photos/seed/quality/800/800" 
                alt="Quality Craftsmanship" 
                fill 
                className="object-cover"
                data-ai-hint="luxury texture"
              />
            </div>
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-headline leading-tight">Crafted with Uncompromising Detail</h2>
              <p className="text-muted-foreground text-lg leading-relaxed">
                At Aura, we believe luxury isn't just about the label—it's about the feeling of superior materials against your skin and the confidence that comes from impeccable tailoring.
              </p>
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-2">
                  <h4 className="font-bold uppercase tracking-widest text-xs">Sustainable Sourcing</h4>
                  <p className="text-sm text-muted-foreground">Every fiber is chosen for its longevity and ethical footprint.</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-bold uppercase tracking-widest text-xs">Artisan Finished</h4>
                  <p className="text-sm text-muted-foreground">Small-batch production ensures the highest quality control.</p>
                </div>
              </div>
              <Button size="lg" className="rounded-full">Learn Our Story</Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-primary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <h3 className="text-3xl font-headline">Aura</h3>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs">
              Defining the pinnacle of modern luxury. High-end collections for those who seek the extraordinary.
            </p>
          </div>
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6">Collections</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li><Link href="#" className="hover:text-white">Summer 2024</Link></li>
              <li><Link href="#" className="hover:text-white">Signature Series</Link></li>
              <li><Link href="#" className="hover:text-white">Evening Wear</Link></li>
              <li><Link href="#" className="hover:text-white">Accessories</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6">Support</h4>
            <ul className="space-y-4 text-sm text-white/60">
              <li><Link href="#" className="hover:text-white">Contact Us</Link></li>
              <li><Link href="#" className="hover:text-white">Shipping Policy</Link></li>
              <li><Link href="#" className="hover:text-white">Returns & Exchanges</Link></li>
              <li><Link href="#" className="hover:text-white">Size Guide</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6">Newsletter</h4>
            <p className="text-sm text-white/60 mb-4">Join our inner circle for exclusive previews.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="email@aura.com" 
                className="bg-white/10 border-white/20 rounded-md px-4 py-2 flex-1 text-sm outline-none focus:bg-white/20"
              />
              <Button variant="secondary" size="sm">Join</Button>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-20 pt-8 border-t border-white/10 text-center text-xs text-white/40">
          &copy; 2024 Aura Commerce. All rights reserved.
        </div>
      </footer>

      <CartDrawer />
    </div>
  );
}
