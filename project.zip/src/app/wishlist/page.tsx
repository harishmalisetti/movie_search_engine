
"use client";

import { useStore } from '@/components/store-provider';
import { Navbar } from '@/components/navbar';
import { ProductCard } from '@/components/product-card';
import { CartDrawer } from '@/components/cart-drawer';
import { Heart, ArrowLeft, ShoppingBag } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function WishlistPage() {
  const { wishlist } = useStore();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-primary mb-12 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Continue Shopping
        </Link>

        <div className="flex items-center gap-4 mb-12">
          <div className="p-3 rounded-full bg-primary/5">
            <Heart className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-4xl font-headline font-bold">Your Wishlist</h1>
            <p className="text-muted-foreground">{wishlist.length} saved items in your collection</p>
          </div>
        </div>

        {wishlist.length === 0 ? (
          <div className="py-24 text-center space-y-6">
            <p className="text-xl text-muted-foreground">Your wishlist is currently empty.</p>
            <Link href="/">
              <Button size="lg" className="rounded-full px-8">Discover Collections</Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {wishlist.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      <CartDrawer />
    </div>
  );
}
