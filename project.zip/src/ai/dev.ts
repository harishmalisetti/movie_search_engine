import { config } from 'dotenv';
config();

import '@/ai/flows/ai-shopping-assistant-chat.ts';
import '@/ai/flows/intelligent-product-search.ts';
import '@/ai/flows/ai-product-recommendations.ts';