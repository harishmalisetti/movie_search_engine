'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating AI-powered product recommendations.
 *
 * - aiProductRecommendations - A function that handles the AI product recommendation process.
 * - AIProductRecommendationsInput - The input type for the aiProductRecommendations function.
 * - AIProductRecommendationsOutput - The return type for the aiProductRecommendations function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AIProductRecommendationsInputSchema = z.object({
  currentProductId: z.string().describe('The ID of the product currently being viewed by the user.'),
  currentProductDescription:
    z.string().describe('A detailed description of the current product, including its attributes like style, material, color, and intended use.'),
  browsingHistoryProductIds:
    z.array(z.string()).describe('An array of product IDs that the user has viewed in their current session.'),
  browsingHistoryDescriptions:
    z.array(z.string()).describe('An array of descriptions for products in the user\'s browsing history, ordered from most recent to oldest.'),
  currentCategory: z.string().optional().describe('The category the user is currently browsing, if applicable.')
});
export type AIProductRecommendationsInput = z.infer<typeof AIProductRecommendationsInputSchema>;

const AIProductRecommendationsOutputSchema = z.object({
  recommendedProductIds: z.array(z.string()).describe('A list of IDs for recommended products that are related or complementary.'),
  recommendationReason: z.string().describe('A brief explanation of why these products were recommended, focusing on style, occasion, or intent.')
});
export type AIProductRecommendationsOutput = z.infer<typeof AIProductRecommendationsOutputSchema>;

export async function aiProductRecommendations(
  input: AIProductRecommendationsInput
): Promise<AIProductRecommendationsOutput> {
  return aiProductRecommendationsFlow(input);
}

const productRecommendationsPrompt = ai.definePrompt({
  name: 'productRecommendationsPrompt',
  input: { schema: AIProductRecommendationsInputSchema },
  output: { schema: AIProductRecommendationsOutputSchema },
  prompt: `You are an expert e-commerce product recommendation system for a high-end luxury store called Aura Commerce.\nYour goal is to suggest related or complementary products based on the user's current view and browsing history,\nconsidering style, occasion, and intent. Provide product IDs and a concise reason for the recommendation.\n\nHere is the context:\n\nCurrent Product ID: {{{currentProductId}}}\nCurrent Product Description: {{{currentProductDescription}}}\n\n{{#if browsingHistoryProductIds.length}}\nUser's Recent Browsing History (Product IDs and Descriptions, from most recent to oldest):\n{{#each browsingHistoryProductIds}}\n- ID: {{{this}}}\n  Description: {{{lookup ../browsingHistoryDescriptions @index}}}\n{{/each}}\n{{else}}\nNo recent browsing history available.\n{{/if}}\n\n{{#if currentCategory}}\nUser is currently browsing in the "{{{currentCategory}}}" category.\n{{/if}}\n\nBased on this information, recommend up to 3 product IDs that are either similar, complementary, or align with the user's likely intent or style.\nThe recommended products should make sense in the context of a luxury e-commerce store.\nOutput the recommended product IDs and a short explanation for your choices.`
});

const aiProductRecommendationsFlow = ai.defineFlow(
  {
    name: 'aiProductRecommendationsFlow',
    inputSchema: AIProductRecommendationsInputSchema,
    outputSchema: AIProductRecommendationsOutputSchema,
  },
  async (input) => {
    const { output } = await productRecommendationsPrompt(input);
    if (!output) {
      throw new Error('Failed to get product recommendations from the AI.');
    }
    return output;
  }
);
