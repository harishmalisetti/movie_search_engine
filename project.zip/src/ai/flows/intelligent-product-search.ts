'use server';
/**
 * @fileOverview An AI-powered product search tool that interprets natural language queries.
 *
 * - intelligentProductSearch - A function that handles natural language product search.
 * - IntelligentProductSearchInput - The input type for the intelligentProductSearch function.
 * - IntelligentProductSearchOutput - The return type for the intelligentProductSearch function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const IntelligentProductSearchInputSchema = z.object({
  query: z.string().describe('The natural language search query from the user.'),
});
export type IntelligentProductSearchInput = z.infer<typeof IntelligentProductSearchInputSchema>;

const IntelligentProductSearchOutputSchema = z.object({
  suggestions: z
    .array(z.string())
    .describe('An array of product suggestions based on the user\'s query.'),
});
export type IntelligentProductSearchOutput = z.infer<typeof IntelligentProductSearchOutputSchema>;

export async function intelligentProductSearch(
  input: IntelligentProductSearchInput
): Promise<IntelligentProductSearchOutput> {
  return intelligentProductSearchFlow(input);
}

const prompt = ai.definePrompt({
  name: 'intelligentProductSearchPrompt',
  input: {schema: IntelligentProductSearchInputSchema},
  output: {schema: IntelligentProductSearchOutputSchema},
  prompt: `You are an intelligent e-commerce assistant designed to interpret natural language queries for clothing and accessories. Your goal is to suggest relevant product descriptions based on the user's style, occasion, and intent, even if the keywords are not exact matches. Provide concise, high-level product suggestions without specific brand names or prices, focusing on categories, styles, and materials.

User Query: {{{query}}}`,
});

const intelligentProductSearchFlow = ai.defineFlow(
  {
    name: 'intelligentProductSearchFlow',
    inputSchema: IntelligentProductSearchInputSchema,
    outputSchema: IntelligentProductSearchOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
