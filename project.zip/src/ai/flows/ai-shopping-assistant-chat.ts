'use server';
/**
 * @fileOverview An AI shopping assistant chatbot that answers questions about product details, sizing, materials, or general store policies.
 *
 * - aiShoppingAssistantChat - A function that handles the AI chatbot interaction.
 * - AiShoppingAssistantChatInput - The input type for the aiShoppingAssistantChat function.
 * - AiShoppingAssistantChatOutput - The return type for the aiShoppingAssistantChat function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiShoppingAssistantChatInputSchema = z
  .string()
  .describe('The user\'s natural language query to the AI shopping assistant.');
export type AiShoppingAssistantChatInput = z.infer<typeof AiShoppingAssistantChatInputSchema>;

const AiShoppingAssistantChatOutputSchema = z
  .string()
  .describe('The AI\'s natural language response to the user\'s query.');
export type AiShoppingAssistantChatOutput = z.infer<typeof AiShoppingAssistantChatOutputSchema>;

export async function aiShoppingAssistantChat(input: AiShoppingAssistantChatInput): Promise<AiShoppingAssistantChatOutput> {
  return aiShoppingAssistantChatFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiShoppingAssistantChatPrompt',
  input: {schema: AiShoppingAssistantChatInputSchema},
  output: {schema: AiShoppingAssistantChatOutputSchema},
  prompt: `You are an AI shopping assistant for an e-commerce store called Aura Commerce.
Your role is to help shoppers by answering questions about product details, sizing, materials, or general store policies.
Be helpful, accurate, and concise. If you don't know the answer, politely state that you cannot provide the information.

User's Query: {{{this}}}`,
});

const aiShoppingAssistantChatFlow = ai.defineFlow(
  {
    name: 'aiShoppingAssistantChatFlow',
    inputSchema: AiShoppingAssistantChatInputSchema,
    outputSchema: AiShoppingAssistantChatOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
